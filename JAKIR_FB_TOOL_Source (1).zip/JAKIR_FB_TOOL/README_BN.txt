JAKIR FB TOOL — Android project

ফিচার:
- Facebook ওয়েবসাইট অ্যাপের ভিতরে WebView-তে খোলে
- নিজের UID লিখে Copy UID করা যায়
- Clear Cookies: WebView-এর cookies মুছে দেয়
- Clear Data: WebView cache, history, form data ও cookies মুছে দেয়

নিরাপত্তা:
- অ্যাপ Facebook password বা login cookies সংগ্রহ/দেখায়/কপি করে না।
- Facebook কখনও কখনও embedded WebView login সীমিত করতে পারে। সে ক্ষেত্রে Facebook-এর নিজস্ব অ্যাপ/ব্রাউজার ব্যবহার করুন।
- UID বাটনটি UID নিজে প্রবেশ করালে কপি করে; Facebook পেজ থেকে স্বয়ংক্রিয়ভাবে UID বের করে না।

APK বানানোর ফ্রি উপায় (কম্পিউটার থাকলে):
1. Android Studio ইনস্টল করুন (developer.android.com/studio থেকে বিনামূল্যে)।
2. Android Studio > Open চাপুন এবং এই ফোল্ডারটি নির্বাচন করুন।
3. Gradle sync শেষ হতে দিন। JDK 17 এবং Android SDK Platform 35 ইনস্টল থাকতে হবে।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. সফল হলে Android Studio-তে Locate চাপুন। সাধারণত APK থাকবে app/build/outputs/apk/debug/app-debug.apk এ।
6. APK ফোনে পাঠিয়ে ইনস্টল করুন। Android-এ প্রয়োজন হলে “Install unknown apps” অনুমতি দিন।

শুধু Android ফোন থাকলে:
- এই ZIP-টি GitHub-এ নতুন repository হিসেবে আপলোড করুন, তারপর GitHub Actions-এ Android build workflow যোগ করে APK বানানো যায়। সহজ বিকল্প হলো Android Studio-সহ কম্পিউটার ব্যবহার করা।

প্রজেক্টের applicationId: com.jakir.fbtool
ন্যূনতম Android: 6.0 (API 23)
