package com.jakir.fbtool;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;

public class MainActivity extends Activity {
    private static final int BLUE = Color.rgb(24, 119, 242);
    private WebView webView;
    private EditText uidInput;
    private LinearLayout root;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(20, 93, 191));
        getWindow().setNavigationBarColor(Color.WHITE);
        buildScreen();
    }

    private void buildScreen() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 247, 250));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(18), dp(16), dp(18), dp(16));
        header.setBackgroundColor(BLUE);
        TextView title = new TextView(this);
        title.setText("JAKIR FB TOOL");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("Facebook WebView • UID tools");
        subtitle.setTextColor(Color.WHITE);
        subtitle.setTextSize(13);
        header.addView(subtitle);
        root.addView(header);

        ScrollView toolsScroll = new ScrollView(this);
        toolsScroll.setFillViewport(false);
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.VERTICAL);
        tools.setPadding(dp(14), dp(10), dp(14), dp(10));
        toolsScroll.addView(tools);
        root.addView(toolsScroll, new LinearLayout.LayoutParams(-1, -2));

        TextView uidLabel = new TextView(this);
        uidLabel.setText("নিজের Facebook UID লিখুন");
        uidLabel.setTextColor(Color.rgb(40, 50, 65));
        uidLabel.setTextSize(14);
        uidLabel.setTypeface(null, Typeface.BOLD);
        tools.addView(uidLabel);
        uidInput = new EditText(this);
        uidInput.setSingleLine(true);
        uidInput.setHint("যেমন: 100012345678901");
        uidInput.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        uidInput.setTextSize(15);
        uidInput.setPadding(dp(12), dp(8), dp(12), dp(8));
        tools.addView(uidInput, new LinearLayout.LayoutParams(-1, dp(48)));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        Button copyUid = makeButton("Copy UID", BLUE);
        Button openFb = makeButton("Open Facebook", Color.rgb(40, 155, 90));
        row1.addView(copyUid, new LinearLayout.LayoutParams(0, dp(46), 1));
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(46), 1);
        p2.leftMargin = dp(8);
        row1.addView(openFb, p2);
        tools.addView(row1);
        copyUid.setOnClickListener(v -> copyUid());
        openFb.setOnClickListener(v -> loadFacebook());

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button clearCookies = makeButton("Clear Cookies", Color.rgb(220, 120, 30));
        Button clearData = makeButton("Clear Data", Color.rgb(190, 45, 55));
        row2.addView(clearCookies, new LinearLayout.LayoutParams(0, dp(46), 1));
        LinearLayout.LayoutParams p4 = new LinearLayout.LayoutParams(0, dp(46), 1);
        p4.leftMargin = dp(8);
        row2.addView(clearData, p4);
        tools.addView(row2);
        clearCookies.setOnClickListener(v -> confirmClearCookies());
        clearData.setOnClickListener(v -> confirmClearData());

        TextView note = new TextView(this);
        note.setText("নোট: Facebook-এর নিরাপত্তার কারণে অ্যাপটি লগইন কুকিজ দেখায় বা কপি করে না। UID নিজে লিখে কপি করুন। Clear Data করলে এই অ্যাপের WebView থেকে লগআউট হতে পারেন।");
        note.setTextColor(Color.rgb(90, 98, 110));
        note.setTextSize(12);
        note.setPadding(0, dp(8), 0, dp(4));
        tools.addView(note);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        root.addView(webView, new LinearLayout.LayoutParams(-1, 0, 1));
        loadFacebook();
    }

    private Button makeButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(null, Typeface.BOLD);
        b.setPadding(dp(4), 0, dp(4), 0);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(10));
        b.setBackground(bg);
        return b;
    }

    private void loadFacebook() {
        if (webView != null) webView.loadUrl("https://www.facebook.com/");
    }

    private void copyUid() {
        String uid = uidInput.getText().toString().trim();
        if (uid.isEmpty()) {
            Toast.makeText(this, "আগে নিজের UID লিখুন", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Facebook UID", uid));
        Toast.makeText(this, "UID কপি হয়েছে", Toast.LENGTH_SHORT).show();
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(uidInput.getWindowToken(), 0);
    }

    private void confirmClearCookies() {
        new AlertDialog.Builder(this)
            .setTitle("Clear Cookies?")
            .setMessage("এই অ্যাপের WebView-এর Facebook cookies মুছে যাবে। আবার লগইন করতে হতে পারে।")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear", (d, w) -> {
                CookieManager cm = CookieManager.getInstance();
                cm.removeAllCookies(success -> {
                    cm.flush();
                    Toast.makeText(this, "Cookies পরিষ্কার হয়েছে", Toast.LENGTH_SHORT).show();
                    loadFacebook();
                });
            }).show();
    }

    private void confirmClearData() {
        new AlertDialog.Builder(this)
            .setTitle("Clear WebView Data?")
            .setMessage("Cookies, cache, history এবং form data মুছে যাবে। চালিয়ে যাবেন?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear Data", (d, w) -> {
                CookieManager.getInstance().removeAllCookies(null);
                CookieManager.getInstance().flush();
                if (webView != null) {
                    webView.clearCache(true);
                    webView.clearHistory();
                    webView.clearFormData();
                    webView.loadUrl("about:blank");
                }
                Toast.makeText(this, "WebView data পরিষ্কার হয়েছে", Toast.LENGTH_SHORT).show();
                loadFacebook();
            }).show();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private int dp(int value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
